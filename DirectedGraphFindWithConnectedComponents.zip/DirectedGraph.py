import copy
import random
from random import randint

class DirectedGraph:
    def __init__(self, nrVertices, nrEdges):
        self.__nrVertices = nrVertices
        self.__nrEdges = nrEdges
        self._dictOut = {}  # create an empty dictionary for the Out vertices
        self._dictCosts = {}
        for i in range(nrVertices):
            self._dictOut[i] = []  # create an empty list for each vertex

    def parseVertices(self):
        vertices = []
        for i in self._dictOut.keys():
            vertices.append(i)
        return vertices # returns an iterable containing all the vertices

    def parseEdges(self):
        return self._dictCosts

    def parseNout(self, vertex):
        return self._dictOut[vertex]  # return an iterable containing all the out vertices for the vertex "vertex"

    def isEdge(self, outVertex, inVertex):
        if not self.isVertex(outVertex) or not self.isVertex(inVertex):  # check if the vertices exist
            raise ValueError("One of the vertices does not exist!\n")
        return (inVertex in self._dictOut[outVertex]  and outVertex in self._dictOut[inVertex]) # check if "outVertex" is an out vertex for the vertex "inVertex"  so if there is an edge from outVertex to invertex

    def isVertex(self, vertex):
        return vertex in self._dictOut.keys()  # check if the vertex "vertex" exists

    def addEdge(self, outVertex, inVertex, cost):
        if self.isEdge(outVertex, inVertex):
            return;
        self._dictOut[outVertex].append(inVertex)
        self._dictOut[inVertex].append(outVertex)
        self._dictCosts[(outVertex, inVertex)] = cost
        self._dictCosts[(inVertex, outVertex)] = cost

    def addVertex(self, vertex):
        if vertex in self.parseVertices():
            print("existing Vertex!")
            return;
        self.__nrVertices += 1
        self._dictOut[vertex] = []

    def getGraphFromFile(self, fileName):
        with open(fileName, "r") as f:
            f.readline()
            for i in range(self.__nrEdges):
                line = f.readline()
                line = line.split()
                outVertex = int(line[0])
                inVertex = int(line[1])
                cost = int(line[2])
                if(not self.isEdge(outVertex, inVertex)):
                    self.addEdge(outVertex, inVertex, cost)

    def writeGraphToFile(self, fileName):
        with open(fileName, "w") as f:
            line = ''
            line = line + str(self.getNrVertices()) + " " + str(self.getNrEdges()) + '\n'
            f.write(line)
            for edge in self._dictCosts:
                line = ''
                line = line + str(edge[0]) + ' ' + str(edge[1]) + ' ' + str(self.getCost(edge)) + '\n'
                f.write(line)

    def getNrVertices(self):
        self.__nrVertices = len(self._dictIn)
        return self.__nrVertices

    def getOutDegree(self, vertex):
        if self.isVertex(vertex):
            return len(self._dictOut[vertex])
        print("There is no such vertex!")

    def parseOutboundEdges(self, vertex):
        outBoundEdges = []
        for edge in self._dictCosts.keys():
            if edge[0] == vertex:
                outBoundEdges.append(edge)
        return outBoundEdges

    def getNrEdges(self):
        return len(self._dictCosts.keys())

    def removeEdge(self, edge_id):
        if not self.isEdge(edge_id[0], edge_id[1]):
            print("There is no such an edge!")
            return
        inVertex = edge_id[1]
        outVertex = edge_id[0]
        self._dictOut[outVertex].remove(inVertex)
        self._dictOut[inVertex].remove(outVertex)
        del self._dictCosts[edge_id]

    def removeVertex(self, vertex_id):
        #outboundEdges = self.parseOutboundEdges(vertex_id)
        #inBoundEdges = self.parseInboundEdges(vertex_id)
        if not self.isVertex(vertex_id):
            print("There is no such vertex!")
            return

        for inVertex in self._dictOut[vertex_id]:
                del self._dictCosts[(vertex_id, inVertex)]
                self._dictOut[inVertex].remove(vertex_id)

        del self._dictOut[vertex_id]

    def getCost(self, edge_id):
        return self._dictCosts[edge_id]

    def modifyCost(self, edge_id, newCost):
        self._dictCosts[edge_id] = newCost

    def copyGraph(self):
        copyOfGraph = copy.deepcopy(self);
        return copyOfGraph

    def randomGraph(self, nrVertices, nrEdges):
        randomGraph = DirectedGraph(nrVertices,nrEdges)
        vertices = []
        for vertex in range(nrVertices):
            vertices.append(int(vertex))
        for i in range(nrEdges):
            outVertex = random.choice(vertices)
            inVertex = random.choice(vertices)
            while (outVertex, inVertex) in randomGraph._dictCosts.keys():
                outVertex = random.choice(vertices)
                inVertex = random.choice(vertices)
            randomGraph.addEdge(outVertex, inVertex, randint(-1000,1000))
        return randomGraph

    def printGraph(self):
        vertices = self.parseVertices()
        for vertex in vertices:
            print(vertex)
            print(self.parseNout(vertex))
            print("\n")

        edges = self.parseEdges()
        for edge in edges:
            print(str(edge) + " - " + str(edges[edge]))

    def accessible(self, vertex):
        component = DirectedGraph(0, 0)
        component.addVertex(vertex)
        deque = [vertex]
        while len(deque) > 0:
            node = deque.pop(0)
            outVertices = self.parseNout(node)
            for i in outVertices:
                if not component.isVertex(i):
                    deque.append(i)
                    component.addVertex(i)
                component.addEdge(node, i, 0)
        return component

    def ShowComponents(self):
        vertices = self.parseVertices()
        count = 0
        while len(vertices) > 0:
            component = self.accessible(vertices[0])
            for i in component.parseVertices():
                vertices.remove(i)
            component.printGraph()
            count+=1
        print("the graph have " + str(count) + " connected components")
"""
graph = DirectedGraph(6, 6)

graph.addEdge(0, 1, 0);
graph.addEdge(1, 2, 0);
graph.addEdge(3, 4, 0);

graph.ShowComponents()
"""

while(True):
    print("input a command: ")
    command = input()
    command = command.split()
    instruction = command[0]
    parameters = command[1:]
    if(instruction == "exit"):
        break
    elif instruction == "text":
        with open(parameters[0], "r")as f:
            firstLine = f.readline()
            firstLine = firstLine.split()
            nrVertices = int(firstLine[0])
            nrEdges = int(firstLine[1])
        graph = DirectedGraph(nrVertices, nrEdges)
        graph.getGraphFromFile(parameters[0])
    elif instruction == "random":
        graph = DirectedGraph(int(parameters[0]), int(parameters[1]))
        graph = graph.randomGraph(int(parameters[0]),int(parameters[1]))
        graph.writeGraphToFile("randomgraph.txt")
    elif instruction == "print":
        graph.printGraph()
    elif instruction == "parse_vertices":
        print(graph.parseVertices())
    elif instruction == "parse_edges":
        print(graph.parseEdges())
    elif instruction == "nr_vertices":
        print(graph.getNrVertices())
    elif instruction == "nr_edges":
        print(graph.getNrEdges())
    elif instruction == "is_edge":
        try:
            print(graph.isEdge(int(parameters[0]),int(parameters[1])))
        except Exception as e:
            print(e)
    elif instruction == "out_degree":
        print(graph.getOutDegree(int(parameters[0])))
    elif instruction == "parse_outbound":
        print(graph.parseOutboundEdges(int(parameters[0])))
    elif instruction == "modify_cost":
        graph.modifyCost((int(parameters[0]), int(parameters[1])), int(parameters[2]))
        print("cost of " + str(parameters[0]) + " " + str(parameters[1]) + " is " + str(graph.getCost((int(parameters[0]), int(parameters[1])))))
    elif instruction == "add_edge":
        graph.addEdge(int(parameters[0]), int(parameters[1]), int(parameters[2]))
    elif instruction == "remove_edge":
        graph.removeEdge((int(parameters[0]), int(parameters[1])))
    elif instruction == "add_vertex":
        graph.addVertex(int(parameters[0]))
    elif instruction == "remove_vertex":
        graph.removeVertex(int(parameters[0]))
    elif instruction == "get_cost":
        print(graph.getCost((int(parameters[0]), int(parameters[1]))))
    elif instruction == "save_to_file":
        graph.writeGraphToFile(parameters[0])
    elif instruction == "connected_components":
        graph.ShowComponents();
    else:
        print("wrong instruction!")






