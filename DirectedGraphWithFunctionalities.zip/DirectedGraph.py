import copy
import random
from random import randint

class DirectedGraph:
    def __init__(self, nrVertices, nrEdges):
        self.__nrVertices = nrVertices
        self.__nrEdges = nrEdges
        self._dictOut = {}  # create an empty dictionary for the Out vertices
        self._dictIn = {}  # create an empty dictionary for the In vertices
        self._dictCosts = {}
        for i in range(nrVertices):
            self._dictOut[i] = []  # create an empty list for each vertex
            self._dictIn[i] = []

    def parseVertices(self):
        return self._dictOut.keys()  # returns an iterable containing all the vertices

    def parseEdges(self):
        return self._dictCosts

    def parseNin(self, vertex):
        return self._dictIn[vertex]  # returns an iterable containing all the in vertices for the vertex "vertex"

    def parseNout(self, vertex):
        return self._dictOut[vertex]  # return an iterable containing all the out vertices for the vertex "vertex"

    def isEdge(self, outVertex, inVertex):
        if not self.isVertex(outVertex) or not self.isVertex(inVertex):  # check if the vertices exist
            raise ValueError("One of the vertices does not exist!\n")
        return inVertex in self._dictOut[outVertex]  # check if "outVertex" is an out vertex for the vertex "inVertex"  so if there is an edge from outVertex to invertex

    def isVertex(self, vertex):
        return vertex in self._dictOut.keys()  # check if the vertex "vertex" exists

    def addEdge(self, outVertex, inVertex, cost):
        if self.isEdge(outVertex, inVertex):
            raise ValueError("The edge does already exist!\n")  # check if the edge does not already exists
        self._dictOut[outVertex].append(inVertex)
        self._dictIn[inVertex].append(outVertex)
        self._dictCosts[(outVertex, inVertex)] = cost

    def addVertex(self, vertex):
        if vertex in self.parseVertices():
            print("existing Vertex!")
            return;
        self.__nrVertices += 1
        self._dictIn[vertex] = []
        self._dictOut[vertex] = []

    def getGraphFromFile(self, fileName):
        with open(fileName, "r") as f:
            f.readline()
            for i in range(self.__nrEdges):
                line = f.readline()
                line = line.split()
                print(line)
                outVertex = int(line[0])
                inVertex = int(line[1])
                cost = int(line[2])
                self.addEdge(outVertex, inVertex, cost)

    def writeGraphToFile(self, fileName):
        with open(fileName, "w") as f:
            line = ''
            line = line + str(self.getNrVertices()) + " " + str(self.getNrEdges()) + '\n'
            f.write(line)
            for edge in self._dictCosts:
                line = ''
                line = line + str(edge[0]) + ' ' + str(edge[1]) + ' ' + str(self.getCost(edge)) + '\n'
                f.write(line)

    def getNrVertices(self):
        self.__nrVertices = len(self._dictIn)
        return self.__nrVertices

    def getInDegree(self, vertex):
        if self.isVertex(vertex):
            return len(self._dictIn[vertex])
        print("There is no such vertex!")

    def getOutDegree(self, vertex):
        if self.isVertex(vertex):
            return len(self._dictOut[vertex])
        print("There is no such vertex!")

    def parseOutboundEdges(self, vertex):
        outBoundEdges = []
        for edge in self._dictCosts.keys():
            if edge[0] == vertex:
                outBoundEdges.append(edge)
        return outBoundEdges

    def parseInboundEdges(self, vertex):
        outInEdges = []
        for edge in self._dictCosts.keys():
            if edge[1] == vertex:
                outInEdges.append(edge)
        return outInEdges

    def getNrEdges(self):
        return len(self._dictCosts.keys())

    def removeEdge(self, edge_id):
        if not self.isEdge(edge_id[0], edge_id[1]):
            print("There is no such an edge!")
            return
        inVertex = edge_id[1]
        outVertex = edge_id[0]
        self._dictOut[outVertex].remove(inVertex)
        self._dictIn[inVertex].remove(outVertex)
        del self._dictCosts[edge_id]

    def removeVertex(self, vertex_id):
        #outboundEdges = self.parseOutboundEdges(vertex_id)
        #inBoundEdges = self.parseInboundEdges(vertex_id)
        if not self.isVertex(vertex_id):
            print("There is no such vertex!")
            return

        for inVertex in self._dictOut[vertex_id]:
                del self._dictCosts[(vertex_id, inVertex)]
                self._dictIn[inVertex].remove(vertex_id)

        del self._dictOut[vertex_id]

        for outVertex in self._dictIn[vertex_id]:
            del self._dictCosts[(outVertex, vertex_id)]
            self._dictOut[outVertex].remove(vertex_id)

        del self._dictIn[vertex_id]

    def getCost(self, edge_id):
        return self._dictCosts[edge_id]

    def modifyCost(self, edge_id, newCost):
        self._dictCosts[edge_id] = newCost

    def copyGraph(self):
        copyOfGraph = copy.deepcopy(self);
        return copyOfGraph

    def randomGraph(self, nrVertices, nrEdges):
        randomGraph = DirectedGraph(nrVertices,nrEdges)
        vertices = []
        for vertex in range(nrVertices):
            vertices.append(int(vertex))
        for i in range(nrEdges):
            outVertex = random.choice(vertices)
            inVertex = random.choice(vertices)
            while (outVertex, inVertex) in randomGraph._dictCosts.keys():
                outVertex = random.choice(vertices)
                inVertex = random.choice(vertices)
            randomGraph.addEdge(outVertex, inVertex, randint(-1000,1000))
        return randomGraph

    def printGraph(self):
        vertices = self.parseVertices()
        for vertex in vertices:
            print(vertex)
            print(self.parseNin(vertex))
            print(self.parseNout(vertex))
            print("\n")

        edges = self.parseEdges()
        for edge in edges:
            print(str(edge) + " - " + str(edges[edge]))

    def TopologicalSort(self):
        sorted = []
        queue = []
        count = {}
        for x in self.parseVertices():
            count[x] = len(self.parseNin(x))
            if count[x] == 0:
                queue.append(x)

        while not len(queue) == 0:
            x = queue[0]
            queue.remove(x)
            sorted.append(x)
            for y in self.parseNout(x):
                count[y] = count[y] - 1
                if count[y] == 0:
                    queue.append(y)

        if len(sorted) < self.__nrVertices:
            raise Exception("not a DAG!")

        print("A topological order is: ", sorted)
        return sorted

    def Schedule(self):
        sorted = self.TopologicalSort()
        timing = {}
        timing[0] = [0,0]
        sorted.remove(0)

        for x in sorted:
            timing[x] = []
            maxTime = 0
            for y in self.parseNin(x):
                somePreviousNode = y
                if timing[y][1] > maxTime:
                    maxTime = timing[y][1]
            duration = self.getCost((somePreviousNode, x))
            timing[x].append(maxTime)
            timing[x].append(maxTime+duration)

        print("early scheduling:",timing)

        sorted.reverse()
        Ltiming = {}
        Ltiming[sorted[0]] = [0, 0]
        sorted.remove(sorted[0])
        sorted.append(0)

        for x in sorted:
            Ltiming[x] = []
            minTime = 0
            for y in self.parseNout(x):
                if Ltiming[y][0] < minTime:
                    minTime = Ltiming[y][0]

            if x == 0:
                duration = 0
            else:
                duration = -self.getCost((self.parseNin(x)[0], x))
            Ltiming[x].append(minTime+duration)
            Ltiming[x].append(minTime)

        print("\n")
        totalTime = -Ltiming[0][0]
        criticalPoints = []
        for x in Ltiming:
            Ltiming[x][0] = Ltiming[x][0]+totalTime
            Ltiming[x][1] = Ltiming[x][1]+totalTime
            if Ltiming[x][0] == timing[x][0] and Ltiming[x][1] == timing[x][1]:
                criticalPoints.append(x)

        #criticalPoints.pop(0)
        #criticalPoints.pop()
        print("later scheduling:", Ltiming, "\n")
        print("Critical Activities are: ", criticalPoints)


    def Activities(self, fileName):
        with open(fileName, "r") as f:
            f.readline()
            lines = f.readlines()
            for line in lines:
                line = line.split()
                outvertices = line[2].split(",")
                inVertex = int(line[0])
                for x in outvertices:
                    outVertex = int(x)
                    cost = int(line[1])
                    self.addEdge(outVertex, inVertex, cost)
        self.printGraph()

    def nrPaths(self, source, dest):
        s = self.TopologicalSort()
        paths = []
        for vertex in s:
            paths.append(0)
        paths[dest]=1

        s.reverse()
        for i in s:
            for j in self.parseNout(i):
                paths[i] = paths[i] + paths[j]

        print("Number of distinct paths from", source, "to", dest, "is", paths[source])

    def shortestPaths(self, source, dest):
        dist = [float("Inf")] * (self.__nrVertices)
        dist[source] = 0
        s = self.TopologicalSort()
        s.reverse()
        while s:
            i = s.pop()
            for node in self.parseNout(i):
                if dist[node] > dist[i] + self.getCost((i, node)):
                    dist[node] = dist[i] + self.getCost((i, node))

        count = [0]*(self.__nrVertices)
        DFS(self, source, count, dist)
        print("There are", count[dest], "distincts paths with the lowest cost from", source, "to", dest)

def DFS(graph, u, count, dist):
    list = graph.parseNout(u)
    for v in list:
        if dist[v] == (dist[u] + graph.getCost((u,v))):
            count[v] = count[v]+1
            DFS(graph, v, count, dist)

while(True):
    print("input a command: ")
    command = input()
    command = command.split()
    instruction = command[0]
    parameters = command[1:]
    if(instruction == "exit"):
        break
    elif instruction == "text":
        with open(parameters[0], "r")as f:
            firstLine = f.readline()
            firstLine = firstLine.split()
            nrVertices = int(firstLine[0])
            nrEdges = int(firstLine[1])
        graph = DirectedGraph(nrVertices, nrEdges)
        graph.getGraphFromFile(parameters[0])
    elif instruction == "random":
        graph = DirectedGraph(int(parameters[0]), int(parameters[1]))
        graph = graph.randomGraph(int(parameters[0]),int(parameters[1]))
        graph.writeGraphToFile("randomgraph.txt")
    elif instruction == "print":
        graph.printGraph()
    elif instruction == "parse_vertices":
        print(graph.parseVertices())
    elif instruction == "parse_edges":
        print(graph.parseEdges())
    elif instruction == "nr_vertices":
        print(graph.getNrVertices())
    elif instruction == "nr_edges":
        print(graph.getNrEdges())
    elif instruction == "is_edge":
        try:
            print(graph.isEdge(int(parameters[0]),int(parameters[1])))
        except Exception as e:
            print(e)
    elif instruction == "in_degree":
        print(graph.getInDegree(int(parameters[0])))
    elif instruction == "out_degree":
        print(graph.getOutDegree(int(parameters[0])))
    elif instruction == "parse_outbound":
        print(graph.parseOutboundEdges(int(parameters[0])))
    elif instruction == "parse_inbound":
        print(graph.parseInboundEdges(int(parameters[0])))
    elif instruction == "modify_cost":
        graph.modifyCost((int(parameters[0]), int(parameters[1])), int(parameters[2]))
        print("cost of " + str(parameters[0]) + " " + str(parameters[1]) + " is " + str(graph.getCost((int(parameters[0]), int(parameters[1])))))
    elif instruction == "add_edge":
        graph.addEdge(int(parameters[0]), int(parameters[1]), int(parameters[2]))
    elif instruction == "remove_edge":
        graph.removeEdge((int(parameters[0]), int(parameters[1])))
    elif instruction == "add_vertex":
        graph.addVertex(int(parameters[0]))
    elif instruction == "remove_vertex":
        graph.removeVertex(int(parameters[0]))
    elif instruction == "get_cost":
        print(graph.getCost((int(parameters[0]), int(parameters[1]))))
    elif instruction == "save_to_file":
        graph.writeGraphToFile(parameters[0])
    elif instruction == "topoSort":
        try:
            graph.TopologicalSort()
        except Exception as e:
            print(e)
    elif instruction == "schedule":
            graph.Schedule()
    elif instruction == "activities":
        maxVertex = 0
        with open(parameters[0], "r")as f:
            lines = f.readlines()
            for line in lines:
                if(int(line[0]) > maxVertex):
                    maxVertex = int(line[0])

        graph = DirectedGraph(maxVertex+1, 0)
        graph.Activities(parameters[0])
    elif instruction == "nrPaths":
        graph.nrPaths(int(parameters[0]), int(parameters[1]))
    elif instruction == "shortestPaths":
        graph.shortestPaths(int(parameters[0]), int(parameters[1]))
    else:
        print("wrong instruction!")






