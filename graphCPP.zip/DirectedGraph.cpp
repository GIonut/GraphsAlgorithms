#include "DirectedGraph.h"
#include <iterator>
#include <iostream>
#include <fstream>
#include <string>
#include "random.hpp"

using Random = effolkronium::random_static;

DirectedGraph::DirectedGraph() : numberOfVertices(), numberOfEdges() {};


DirectedGraph::DirectedGraph(int numberOfVertices, int numberOfEdges)
{
	this->numberOfVertices = numberOfVertices;
	this->numberOfEdges = numberOfEdges;
	
	int i = 0;

	for (i = 0; i < numberOfVertices; i++)
	{
		vector<int> inVertices;
		vector<int> outVertices;
		this->dictOut.insert(pair<int, vector<int>>(i, inVertices));
		this->dictIn.insert(pair<int, vector<int>>(i, outVertices));
	}

}


vector<int> DirectedGraph::parseVertices()
{
	vector<int> vertices;
	int i = 0;
	int size = (this->dictIn).size();
	for (i = 0; i < size; i++)
		vertices.push_back(i);

	return vertices;
}


vector<Edge> DirectedGraph::parseEdges()
{
	vector<Edge> edges;
	
	map<Edge, int>::iterator iterator;

	for (iterator = this->dictCosts.begin(); iterator != this->dictCosts.end(); ++iterator)
		edges.push_back(iterator->first);

	return edges;
}


int DirectedGraph::getNrVertices()
{
	return this->numberOfVertices;
}


int DirectedGraph::getNrEdges()
{
	return this->numberOfEdges;
}


int DirectedGraph::isVertex(int vertex)
{
	if (vertex >= this->numberOfVertices || vertex < 0)
		return 0; // 0 -invalid Vertex;
	return 1; // 1 valid vertex
}


int DirectedGraph::isEdge(Edge myEdge)
{
	if (!isVertex(get<0>(myEdge)) || !isVertex(get<1>(myEdge)))
		return -1; // invalid edge

	if(this->dictCosts.find(myEdge) == this->dictCosts.end()) // if the edge is not in the graph
			return 0;	// inexisting edge

	return 1; //  the edge is in the graph
}


void DirectedGraph::addEdge(Edge edge, int cost)
{
	int result = this->isEdge(edge);
	if (result == 1 || result == -1)
		throw("could not add the edge!");

	int inVertex = get<1>(edge);
	int outVertex = get<0>(edge);

	(this->dictIn.find(inVertex)->second).push_back(outVertex);
	(this->dictOut.find(outVertex)->second).push_back(inVertex);
	this->dictCosts.insert({ edge, cost });
}


int isEqual(Edge leftSideEdge, Edge rightSideEdge)
{
	return (get<0>(leftSideEdge) == get<0>(rightSideEdge) && get<1>(leftSideEdge) == get<1>(rightSideEdge));
}


int DirectedGraph::getCost(Edge myEdge)
{
	if(this->isEdge(myEdge))
		return this->dictCosts.find(myEdge)->second;
	return 0;
}


int DirectedGraph::getInDegree(int vertex)
{
	if (this->isVertex(vertex)) {
		Vertices vertices = this->parseNin(vertex);
		return vertices.size();
	}
	return 0;
}


int DirectedGraph::getOutDegree(int vertex)
{
	if (this->isVertex(vertex)) {
		Vertices vertices = this->parseNout(vertex);
		return vertices.size();
	}
	return 0;
}


Vertices DirectedGraph::parseNin(int vertex)
{
	
	if (this->isVertex(vertex)) {
		Vertices vertices;
		map<int, Vertices>::iterator iterator;
		for (iterator = this->dictIn.begin(); iterator != this->dictIn.end(); iterator++)
			if (iterator->first == vertex)
				return iterator->second;

		return vertices;
	}
}


Vertices DirectedGraph::parseNout(int vertex)
{
	if (this->isVertex(vertex)) {
		Vertices vertices;
		map<int, Vertices>::iterator iterator;
		for (iterator = this->dictOut.begin(); iterator != this->dictOut.end(); iterator++)
			if (iterator->first == vertex)
				return iterator->second;
		return vertices;
	}
}


void DirectedGraph::modifyCost(Edge myEdge, int newCost)
{
	if(this->isEdge(myEdge))
		this->dictCosts.find(myEdge)->second = newCost;
}


void DirectedGraph::addVertex(int nrVertices)
{
	int i;
	for (i = this->numberOfVertices; i < this->numberOfVertices + nrVertices; i++)
	{
		Vertices inVertices;
		Vertices outVertices;
		this->dictOut.insert(pair<int, Vertices>(i, inVertices));
		this->dictIn.insert(pair<int, Vertices>(i, outVertices));
	}
}


void DirectedGraph::removeEdge(Edge myEdge)
{
	if (this->isEdge(myEdge) != 1)
		return;

	int inVertex = get<1>(myEdge);
	int outVertex = get<0>(myEdge);

	auto i = this->dictIn[inVertex].begin();
	while (i != this->dictIn[inVertex].end() && *i != outVertex)
	{
		i++;
	}
	auto j = this->dictOut[outVertex].begin();
	while(j != this->dictOut[outVertex].end() && *j != inVertex)
	{
		j++;
	}		

	(this->dictIn[inVertex]).erase(i);
	(this->dictOut[outVertex]).erase(j);

	this->dictCosts.erase(myEdge);
}


void DirectedGraph::removeVertex(int vertex_id)
{
	if (this->isVertex(vertex_id)) {
		for (auto inVertex : this->dictOut[vertex_id])
		{
			this->dictCosts.erase(make_tuple(vertex_id, inVertex));
			auto it = this->dictIn[inVertex].begin();
			while (it != this->dictIn[inVertex].end() && *it != vertex_id)
			{
				it++;
			}

			(this->dictIn[inVertex]).erase(it);
		}

		this->dictOut.erase(vertex_id);

		for (auto outVertex : this->dictIn[vertex_id])
		{
			this->dictCosts.erase(make_tuple(outVertex, vertex_id));
			auto j = this->dictOut[outVertex].begin();
			while (j != this->dictOut[outVertex].end() && *j != vertex_id)
			{
				j++;
			}

			this->dictOut[outVertex].erase(j);
		}

		this->dictIn.erase(vertex_id);
	}
}

void DirectedGraph::writeGraphToFile(string fileName)
{
	ofstream f(fileName);
	string line;
	line = line + to_string(this->getNrVertices()) + " " + to_string(this->getNrEdges()) + "\n";
	f << line;
	for (auto edge : this->parseEdges())
	{
		line = "";
		line = line + to_string(get<0>(edge)) + " " + to_string(get<1>(edge)) + " " + to_string(this->getCost(edge)) + "\n";
		f << line;
	}
}

void DirectedGraph::getRandomGraph(int nrVertices, int nrEdges)
{
	if (nrEdges < nrVertices * nrVertices) {
		DirectedGraph randomGraph(nrVertices, nrEdges);

		for (int i = 0; i < nrEdges; i++)
		{
			int outVertex = Random::get(0, nrVertices - 1);
			int inVertex = Random::get(0, nrVertices - 1);
			while (randomGraph.isEdge(make_tuple(outVertex, inVertex)) == 1) {
				outVertex = Random::get(0, nrVertices - 1);
				inVertex = Random::get(0, nrVertices - 1);
			}

			randomGraph.addEdge(make_tuple(outVertex, inVertex), Random::get(-1000, 1000));
		}

		*this = randomGraph;
	}
	else
	{
		DirectedGraph randomGraph;
		*this = randomGraph;
	}
}

void DirectedGraph::getGraphFromFile(string filename)
{
	int nrVertices, nrEdges;
	ifstream f(filename);
	f >> nrVertices >> nrEdges;

	DirectedGraph textGraph(nrVertices, nrEdges);
	int outVertex, inVertex, cost;
	for (int i = 0; i < nrEdges; i++) {
		f >> outVertex >> inVertex >> cost;
		textGraph.addEdge(make_tuple(outVertex, inVertex), cost);
	}

	*this = textGraph;
}

void DirectedGraph::printGraph()
{
	vector<int> vertices = this->parseVertices();
	for (auto vertex : vertices)
	{
		cout << "\t" << vertex << endl;
		cout << "[ ";
		for (auto vertex : this->parseNin(vertex))
			cout << vertex << " ";
		cout << "]";
		cout << endl;
		cout << "[ ";
		for (auto vertex : this->parseNout(vertex))
			cout << vertex << " ";
		cout << "]";
		cout << "\n\n";
	}
}
