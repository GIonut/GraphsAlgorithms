#pragma once

void tests();