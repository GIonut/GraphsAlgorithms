#pragma once
#include <iterator> 
#include <map> 
#include <vector>
#include <tuple>

using namespace std;

typedef vector<int> Vertices;
typedef tuple<int, int> Edge;

class DirectedGraph
{

private:

	map<int, vector<int>> dictOut;
	map<int, vector<int>> dictIn;
	map< tuple<int, int>, int> dictCosts;
	int numberOfVertices;
	int numberOfEdges;

public:
	DirectedGraph(); // the default contructor
	DirectedGraph(int, int); // the constructor with initializtion

	/*
	returns the number of vertices in the graph
	Input: -
	Output: int - numberOfVertices
	*/
	int getNrVertices();

	/*
	returns the number of edges in the graph
	Input: -
	Output: int - numberOfEdges
	*/
	int getNrEdges();

	/*
	returns a vector containing all vertices in the graph
	Input: -
	Output: vector<int> vertices
	*/
	vector<int> parseVertices();

	/*
	returns a vector containing all the edges in the graph
	Input: -
	Output: vector<Edge> - edges
	*/
	vector<Edge> parseEdges();

	/*
	adds an edge to the graph
	Input:	edge - the edge to be added
			int - the cost of the edge
	Output: -
	*/
	void addEdge(Edge, int);

	/*
	returns the cost of a given edge 
	Input:	Edge
	Output: int - numberOfVertices
			
	*/
	int getCost(Edge);

	/*
	returns the in degree of a given vertex
	Input:	int - vertex 
	Output: int - the number of in vertices
			
	*/
	int getInDegree(int);

	/*
	returns the out degree of a given vertex
	Input:	int - vertex
	Output: int - the number of out vertices
			
	*/
	int getOutDegree(int);

	/*
	returns a vector containing all the in vertices of a vertex
	Input:	int - vertex
	Output: Vertices - the vector of in vertices

	*/
	Vertices parseNin(int);

	/*
	returns a vector containing all the out vertices of a vertex
	Input:	int - vertex
	Output: Vertices - the vector of out vertices

	*/
	Vertices parseNout(int);

	/*
	modifies the cost of a given edge, with a given new cost
	Input:	Edge - the edge
			int - the new cost
	Output: -

	*/
	void modifyCost(Edge, int);

	/*
	checks if the given vertex is in the graph
	Input:	int - vertex
	Output: 1 - if the graph contains the vertex
			0 - otherwise

	*/
	int isVertex(int vertex);

	/*
	checks if the given edge is in the graph
	Input:	Edge - the edge
	Output: 1 - if the graph contains the edge
			0 - otherwise

	*/
	int isEdge(Edge);

	/*
	adds nrVertices more vertices in the graph, that are initialized with an empty list
	Input: int - nrVertices
	Output: - nothing
	*/
	void addVertex(int nrVertices); 

	/*
	removes the given edge from the graph. dictCost, dictIn and dictOut are modified accordingly
	Input:	Edge - the edge
	Output: nothing
	*/
	void removeEdge(Edge);

	/*
	removes the given vertex from the graph. dictCost, dictIn and dictOut are modified accordingly
	Input:	int - the vertex
	Output: nothing
	*/
	void removeVertex(int);
	
	/*
	write the graph in a file with a given name
	Input:	string - the file name
	Output: nothing, the graph was printed in the file
	*/
	void writeGraphToFile(string);

	/*
	generate a random graph wit nrVertices vertices and nrEdges edges
	Input:	int - nrVertices
			int - nrEdges
	Output: nothing
	*/
	void getRandomGraph(int nrVertices, int nrEdges);

	/*
	reads the graph from a file with a given name
	Input:	string - the file name
	Output: nothing
	*/
	void getGraphFromFile(string);

	/*
	prints the graph
	Input:	nothing
	Output: nothing, the graph is printed
	*/
	void printGraph();
};