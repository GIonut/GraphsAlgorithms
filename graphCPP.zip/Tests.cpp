#include "DirectedGraph.h"
#include <vector>
#include <assert.h>
#include "Tests.h"
#include <iostream>

void test_parseVertices()
{
	DirectedGraph graph(5, 3);
	vector<int> vertices = graph.parseVertices();
	
	int i = 0;

	for (i = 0; i < 5; i++)
		assert(vertices[i] == i);
}


void test_getNrVertices()
{
	DirectedGraph graph(5, 3);
	assert(graph.getNrVertices() == 5);
}


void test_getNrEdges()
{
	DirectedGraph graph(5, 3);
	assert(graph.getNrEdges() == 3);
}


void test_addEdge()
{
	DirectedGraph graph(5, 3);
	Edge myEdge = make_tuple(1,3);
	graph.addEdge(myEdge, 7);
	vector<Edge> edges = graph.parseEdges();
	Vertices inVertices = graph.parseNin(3);
	Vertices outVertices = graph.parseNout(1);
	assert(inVertices[0] == 1);
	assert(outVertices[0] == 3);
	assert(get<0>(myEdge) == get<0>(edges[0]) && get<1>(myEdge) == get<1>(edges[0]));
	
}


void test_getCost()
{
	DirectedGraph graph(5, 3);
	Edge myEdge = make_tuple(1, 3);
	graph.addEdge(myEdge, 7);
	int cost = graph.getCost(myEdge);
	assert(cost == 7);
}


void test_getInDegree(DirectedGraph graph)
{
	
	assert(graph.getInDegree(3) == 2);

}


void test_getOutDegree(DirectedGraph graph) {

	assert(graph.getOutDegree(3) == 0);
	assert(graph.getOutDegree(2) == 2);
}

void test_modifyCost(DirectedGraph graph)
{
	Edge myEdge = make_tuple(1, 2);
	graph.modifyCost(myEdge, 10);
	assert(graph.getCost(myEdge) == 10);
	graph.modifyCost(myEdge, 2);
	assert(graph.getCost(myEdge) == 2);
}

void test_isEdge(DirectedGraph graph) {
	assert(graph.isEdge(make_tuple(0, 0)) == 1);// existing edge
	assert(graph.isEdge(make_tuple(9, 2)) == -1);//innvalid edge
	assert(graph.isEdge(make_tuple(3, 1)) == 0);
}


void test_isVertex(DirectedGraph graph) {
	assert(graph.isVertex(0));
	assert(graph.isVertex(3));
	assert(graph.isVertex(5) == 0);
	assert(graph.isVertex(9) == 0);
}



void test_removeEdge(DirectedGraph graph)
{
	Edge edge = make_tuple(2, 3);
	graph.removeEdge(edge);
	assert(graph.isEdge(edge) == 0);
	assert(graph.getInDegree(3) == 1);
	assert(graph.getOutDegree(2) == 1);
	graph.addEdge(edge, 5);
}


void test_removeVertex(DirectedGraph graph)
{
	graph.removeVertex(1);
	assert(graph.parseEdges().size() == 2);

	assert(graph.parseVertices().size() == 4);

}
void tests()
{
	DirectedGraph graph(5, 3);
	Edge myEdge = make_tuple(0, 0);
	graph.addEdge(myEdge, 1);
	myEdge = make_tuple(0, 1);
	graph.addEdge(myEdge, 7);
	myEdge = make_tuple(1, 2);
	graph.addEdge(myEdge, 2);
	myEdge = make_tuple(2, 1);
	graph.addEdge(myEdge, -1);
	myEdge = make_tuple(1, 3);
	graph.addEdge(myEdge, 8);
	myEdge = make_tuple(2, 3);
	graph.addEdge(myEdge, 5);
	

	test_parseVertices();
	test_getNrVertices();
	test_getNrEdges();
	test_addEdge();
	test_getCost();
	test_isVertex(graph);
	test_isEdge(graph);
	test_getInDegree(graph);
	test_getOutDegree(graph);
	test_modifyCost(graph);
	test_removeEdge(graph);
	test_removeVertex(graph);
}