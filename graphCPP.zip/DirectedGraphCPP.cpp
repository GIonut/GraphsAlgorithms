
// DirectedGraphCPP.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <fstream>
#include <iostream>
#include "DirectedGraph.h"
#include "Tests.h"
#include <string>
#include <vector>
#include "random.hpp"

using namespace std;

using Random = effolkronium::random_static;

int main()
{
	tests();
    ifstream f("graph.txt");

    DirectedGraph graph;
    int nrVertices = 0, nrEdges = 0;

    while (true)
    {
        string commandLine;
        cout << "get command:\n";
        getline(cin, commandLine);

        string command = commandLine.substr(0, commandLine.find(" "));

        commandLine = commandLine.erase(0, commandLine.find(" ") + 1);

        int begin = 0;
        int end;

        string parameters[10];

        end = commandLine.find(" ");
        int i = 0;
        while (commandLine.size() > 0)
        {
            parameters[i] = commandLine.substr(begin, end);

            commandLine = commandLine.erase(0, end + 1);
            end = commandLine.find(" ");
            if (end == -1)
                end = commandLine.size();
            i++;
        }
        i--;
        if (command == "exit")
            return 0;

        else if (command == "random")
        {
            nrVertices = stoi(parameters[0]);
            nrEdges = stoi(parameters[1]);

            graph.getRandomGraph(nrVertices, nrEdges);
        }

        else if (command == "text")
        {
            graph.getGraphFromFile(parameters[0]);
        }
        else if (command == "print")
        {
            graph.printGraph();
        }
        else if (command == "parse_vertices")
        {
            for (int i = 0; i < graph.getNrVertices(); i++)
                cout << graph.parseVertices()[i] << " ";
            cout << "\n";
        }
        else if (command == "parse_edges")
        {
            for (int i = 0; i < graph.getNrEdges(); i++)
                cout << get<0>(graph.parseEdges()[i]) << "-" << get<1>(graph.parseEdges()[i]) << " ";
            cout << "\n";
        }
        else if (command == "nr_vertices")
        {
            cout << graph.getNrVertices() << "\n";
        }
        else if (command == "nr_edges")
        {
            cout << graph.getNrEdges() << "\n";
        }
        else if (command == "is_edge")
        {
            int outV = stoi(parameters[0]);
            int inV = stoi(parameters[1]);
            if (graph.isEdge(make_tuple(outV, inV)))
                cout << "True";
            else cout << "False";
            cout << "\n";
        }
        else if (command == "in_degree")
            cout << graph.getInDegree(stoi(parameters[0])) << "\n";
        else if (command == "out_degree")
            cout << graph.getOutDegree(stoi(parameters[0]))<< "\n";
        else if (command == "parse_outbound")
        {
            for (int i = 0; i < graph.getOutDegree(stoi(parameters[0])); i++)
                cout << graph.parseNout(stoi(parameters[0]))[i] << " ";
            cout << "\n";
        }
        else if (command == "parse_inbound")
        {
            for (int i = 0; i < graph.getInDegree(stoi(parameters[0])); i++)
                cout << graph.parseNin(stoi(parameters[0]))[i] << " ";
            cout << "\n";
        }
        else if (command == "modify_cost")
        {
        graph.modifyCost(make_tuple(stoi(parameters[0]), stoi(parameters[1])), stoi(parameters[2]));
            cout << "cost of " << parameters[0] << " " << parameters[1] << " is " << graph.getCost(make_tuple(stoi(parameters[0]), stoi(parameters[1]))) << "\n";
        }
        else if (command == "add_edge")
        {
            graph.addEdge(make_tuple(stoi(parameters[0]), stoi(parameters[1])), stoi(parameters[2]));
        }
        else if (command == "remove_edge")
        {
            graph.removeEdge(make_tuple(stoi(parameters[0]), stoi(parameters[1])));
        }
        else if (command == "add_vertex")
        {
            graph.addVertex(stoi(parameters[0]));
        }
        else if (command == "remove_vertex")
        {
            graph.removeVertex(stoi(parameters[0]));
        }
        else if (command == "get_cost")
        {
            cout << graph.getCost(make_tuple(stoi(parameters[0]), stoi(parameters[1]))) << "\n";
        }
        else if (command == "save_to_file")
        {
            graph.writeGraphToFile(parameters[0]);
        }
        else
            cout << "wrong instruction!\n";
    }
    return 0;
}
